<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Services\QrCodeService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Http\Requests\StoreCargoRequest;
use Yajra\DataTables\Facades\DataTables;
use App\Repositories\Interfaces\CityRepositoryInterface;
use App\Repositories\Interfaces\GateRepositoryInterface;
use App\Repositories\Interfaces\CargoRepositoryInterface;
use App\Repositories\Interfaces\CargoTypeRepositoryInterface;

class AdminCargoController extends Controller
{
    protected $cargoRepository;
    protected $cityRepository;
    protected $cargoTypeRepository;
    protected $gateRepository;
    protected $qrcodeService;

    public function __construct(CargoRepositoryInterface $cargoRepository, CityRepositoryInterface $cityRepository, CargoTypeRepositoryInterface $cargoTypeRepository, GateRepositoryInterface $gateRepository, QrCodeService $qrcodeService)
    {
        $this->cargoRepository = $cargoRepository;
        $this->cityRepository = $cityRepository;
        $this->cargoTypeRepository = $cargoTypeRepository;
        $this->gateRepository = $gateRepository;
        $this->qrcodeService = $qrcodeService;
    }

    /**
     * Show cargos index
     * @return \Illuminate\Contracts\View\View
     */
    public function index()
    {
        $cities = $this->cityRepository->getAllCities();
        $cargoTypes = $this->cargoTypeRepository->getAllCargoTypes();
        $cargos = $this->cargoRepository->getQuery();
        return view('admin.cargos.index', compact('cities', 'cargoTypes'));
    }

    /**
     * Get cargos
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getCargos(Request $request)
    {
        $cargos = $this->cargoRepository->getQuery();
        if ($request->ajax()) {
            return DataTables::of($cargos)
                ->addIndexColumn()
                ->filter(function ($query) use ($request) {
                    if ($request->has('delivery_type') && $request->get('delivery_type') != '') {
                        $query->where('delivery_type', $request->get('delivery_type'));
                    }
                    if ($request->has('from_city_id') && $request->get('from_city_id') != '') {
                        $query->where('from_city_id', $request->get('from_city_id'));
                    }
                    if ($request->has('to_city_id') && $request->get('to_city_id') != '') {
                        $query->where('to_city_id', $request->get('to_city_id'));
                    }
                    if ($request->has('cargo_type_id') && $request->get('cargo_type_id') != '') {
                        $query->where('cargo_type_id', $request->get('cargo_type_id'));
                    }
                    if ($request->has('status') && $request->get('status') != '') {
                        $query->where('status', $request->get('status'));
                    }
                    if ($request->has('daterange') && $request->get('daterange') != '') {
                        $daterange = explode(' - ', $request->get('daterange'));
                        $start = Carbon::parse($daterange[0])->startOfDay();
                        $end = Carbon::parse($daterange[1])->endOfDay();
                        $query->whereBetween('created_at', [$start, $end]);
                    }
                    if ($request->has('cargo_no') && $request->get('cargo_no') != '') {
                        $query->where('cargo_no', $request->get('cargo_no'));
                    }
                })
                ->addColumn('action', function ($cargo) {
                    $edit = '';
                    $delete = '';
                    if (Auth::user()->hasRole('Admin')) {
                        $edit = '<a href="' . route('admin.cargos.edit', [$cargo->id, 'form_type' => 'edit']) . '" class="btn btn-sm btn-warning"><i class="fas fa-edit"></i></a>';
                        $delete = '
                        <form id="delete-form' . $cargo->id . '" action="' . route('admin.cargos.destroy', $cargo->id) . '" method="POST" style="display: none;">
                <input type="hidden" name="_token" value="' . csrf_token() . '">
                <input type="hidden" name="_method" value="DELETE">
                </form>
                <button type="submit" onclick="confirmDelete(' . $cargo->id . ')" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                        ';
                    }
                    return '
                    <div class="d-flex justify-content-center gap-2">
                    <a href="' . route('admin.cargos.show', $cargo->id) . '" class="btn btn-sm btn-primary"><i class="fas fa-eye"></i></a>
                    ' . $edit . '
                    ' . $delete . '
                    </div>
                    ';
                })
                ->addColumn('delivery_type', function ($cargo) {
                    return $cargo->delivery_type == 'home' ? 'အိမ်အရောက်' : 'ဂိတ်ရောက်';
                })
                ->addColumn('cargo_type', function ($cargo) {
                    return $cargo->cargoType->name;
                })
                ->addColumn('from', function ($cargo) {
                    return $cargo->fromCity->name_my . ',' . $cargo->fromGate->name_my;
                })
                ->addColumn('to', function ($cargo) {
                    return $cargo->toCity->name_my . ',' . $cargo->toGate->name_my;
                })
                ->addColumn('s_name', function ($cargo) {
                    return $cargo->sender_merchant->name ?? $cargo->s_name_string;
                })
                ->addColumn('r_name', function ($cargo) {
                    return $cargo->receiver_merchant->name ?? $cargo->r_name_string;
                })
                ->addColumn('status', function ($cargo) {
                    return $this->getCargoStatusMM($cargo->status);
                })
                ->addColumn('created_at', function ($cargo) {
                    return Carbon::parse($cargo->created_at)->format('d/m/Y');
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('admin.cargos.index');
    }

    /**
     * Create cargo
     * @param Request $request
     * @return \Illuminate\Contracts\View\View
     */
    public function create(Request $request)
    {
        return view('admin.cargos.create', ['form_type' => 'create']);
    }

    public function store()
    {
        // 
    }

    /**
     * Edit cargo
     * @param Request $request
     * @param int $id
     * @return \Illuminate\Contracts\View\View
     */
    public function edit(Request $request, $id)
    {
        if (!$id && !$request->get('form_type')) {
            return redirect()->route('admin.cargos.index');
        }
        return view('admin.cargos.edit', ['form_type' => 'edit', 'cargo_id' => $id]);
    }

    /**
     * Show cargo details
     * @param int $id
     * @return \Illuminate\Contracts\View\View
     */
    public function show($id)
    {
        $user = Auth::user();
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return redirect()->route('admin.cargos.index');
        }
        $cargo_image = null;
        if ($cargo->media) {
            $cargo_image = $cargo->media->path;
            $cargo_image = str_replace('\\', '/', $cargo_image);
            $cargo_image = 'uploads/' . $cargo_image;
        }
        $entry_date = Carbon::parse($cargo->created_at)->format('d/m/Y');
        $to_take_date = Carbon::parse($cargo->to_pick_date)->format('d/m/Y');
        $delivery_type = $cargo->delivery_type == 'home' ? 'အိမ်အရောက်' : 'ဂိတ်ရောက်';
        $service_charge = number_format($cargo->service_charge, 2);
        $transit_fee = number_format($cargo->transit_fee, 2);
        $short_deli_fee = number_format($cargo->short_deli_fee, 2);
        $final_deli_fee = number_format($cargo->final_deli_fee, 2);
        $total_fee = number_format($cargo->total_fee, 2);
        $border_fee = number_format($cargo->border_fee, 2);
        $cargo_status = $this->getCargoStatusMM($cargo->status);
        if ($cargo->qrcode_image) {
            $qrcode_image = $cargo->qrcode_image;
        } else {
            $qrcode_image = null;
        }
        return view('admin.cargos.show', compact('cargo', 'user', 'entry_date', 'to_take_date', 'delivery_type', 'service_charge', 'transit_fee', 'short_deli_fee', 'final_deli_fee', 'border_fee', 'total_fee', 'cargo_status', 'qrcode_image', 'cargo_image'));
    }

    /**
     * Get cargo status with Myanmar language
     */
    protected function getCargoStatusMM($type)
    {
        switch ($type) {
            case 'registered':
                return 'စာရင်းသွင်းပြီး';
                break;
            case 'delivered':
                return 'ပို့ပြီး';
                break;
            case 'taken':
                return 'ရွေးပြီး';
                break;
            case 'lost':
                return 'ပျောက်ဆုံး';
                break;
            case 'deleted':
                return 'ပယ်ဖျက်ပြီး';
                break;
            default:
                return '';
                break;
        }
    }

    /**
     * Delete cargo
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return redirect()->route('admin.cargos.index')->with('error', 'Cargo not found');
        }
        $cargo->delete();
        return redirect()->route('admin.cargos.index')->with('success', 'Cargo deleted successfully');
    }

    /**
     * Print voucher
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function printVoucher($id)
    {
        $user = Auth::user();
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return redirect()->route('admin.cargos.index');
        }
        $cargo_image = null;
        if ($cargo->media) {
            $cargo_image = $cargo->media->path;
            $cargo_image = str_replace('\\', '/', $cargo_image);
            $cargo_image = 'uploads/' . $cargo_image;
        }
        $entry_date = Carbon::parse($cargo->created_at)->format('d/m/Y');
        $to_take_date = Carbon::parse($cargo->to_pick_date)->format('d/m/Y');
        $delivery_type = $cargo->delivery_type == 'home' ? 'အိမ်အရောက်' : 'ဂိတ်ရောက်';
        $service_charge = number_format($cargo->service_charge, 2);
        $short_deli_fee = number_format($cargo->short_deli_fee, 2);
        $final_deli_fee = number_format($cargo->final_deli_fee, 2);
        $total_fee = number_format($cargo->total_fee, 2);
        $border_fee = number_format($cargo->border_fee, 2);
        $cargo_status = $this->getCargoStatusMM($cargo->status);
        $qrcode_image = $cargo->qrcode_image;
        return view('admin.cargos.voucher-print', compact('cargo', 'qrcode_image', 'user', 'cargo_image', 'entry_date', 'to_take_date', 'delivery_type', 'service_charge', 'short_deli_fee', 'final_deli_fee', 'border_fee', 'total_fee', 'cargo_status'));
    }
}
