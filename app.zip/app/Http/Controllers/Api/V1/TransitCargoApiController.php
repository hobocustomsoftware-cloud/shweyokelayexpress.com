<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\Interfaces\TransitCargoRepositoryInterface;
use App\Http\Resources\TransitCargoCollection;
use App\Services\ApiResponseService;
use App\Http\Requests\StoreTransitCargoRequest;
use App\Http\Resources\TransitCargoResource;
use App\Repositories\Interfaces\MediaRepositoryInterface;
use App\Repositories\Interfaces\MerchantRepositoryInterface;
use App\Services\QrCodeService;
use Carbon\Carbon;

class TransitCargoApiController extends BaseApiController
{
    protected $mediaRepository;
    protected $merchantRepository;
    public function __construct(TransitCargoRepositoryInterface $transitCargoRepository, MediaRepositoryInterface $mediaRepository, MerchantRepositoryInterface $merchantRepository)
    {
        parent::__construct($transitCargoRepository);
        $this->mediaRepository = $mediaRepository;
        $this->merchantRepository = $merchantRepository;
    }

    public function index(){
        $transitCargoList = $this->repository->getList()->paginate(10);
        $dataCollection = new TransitCargoCollection($transitCargoList);
        return ApiResponseService::sendResponse($dataCollection, 'Successfully get transit cargo list', 200);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-08-13
     */
    public function store(Request $request){
        $validated = $request->validate((new StoreTransitCargoRequest())->rules());
        if ($request->hasFile('image')) {
            $media_id = $this->mediaRepository->create($request->file('image'), 'cargos');
            if (!$media_id) {
                return ApiResponseService::sendError('Failed to upload image');
            }
            $validated['media_id'] = $media_id;
        }
        if ($request->has('s_name')) {
            if (is_numeric($request->s_name)) {
                $merchant = $this->merchantRepository->findById($request->s_name);
                if ($merchant) {
                    $validated['s_merchant_id'] = $merchant->id;
                }
            } else {
                $validated['s_name_string'] = $request->s_name;
            }
        }
        if ($request->has('r_name')) {
            if (is_numeric($request->r_name)) {
                $merchant = $this->merchantRepository->findById($request->r_name);
                if ($merchant) {
                    $validated['r_merchant_id'] = $merchant->id;
                }
            } else {
                $validated['r_name_string'] = $request->r_name;
            }
        }
        unset($validated['s_name']);
        unset($validated['r_name']);
        $validated['cargo_no'] = generateTransitCargoNumber();
        $validated['voucher_number'] = generateTransitCargoVoucherNumber();
        $qrcodeData = json_encode($validated);
        $qrcodeService = new QrCodeService();
        $path = $qrcodeService->saveQrcode($qrcodeData);
        $validated['qrcode_image'] = $path;
        $validated['to_pick_date'] = Carbon::parse($validated['to_pick_date'])->format('Y-m-d');
        $transitCargo = $this->repository->create($validated);
        if(!$transitCargo){
            return ApiResponseService::sendError('Failed to create transit cargo');
        }
        $dataResource = new TransitCargoResource($transitCargo);
        return ApiResponseService::sendResponse($dataResource, 'Successfully create transit cargo', 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-08-13
     */
    public function show($id){
        $transitCargo = $this->repository->find($id);
        if (!$transitCargo) {
            return ApiResponseService::sendError('Transit cargo not found');
        }
        $dataResource = new TransitCargoResource($transitCargo);
        return ApiResponseService::sendResponse($dataResource, 'Successfully get transit cargo', 200);
    }
}
