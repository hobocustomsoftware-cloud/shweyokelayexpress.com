<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Api\V1\BaseApiController;
use App\Repositories\Interfaces\UserRepositoryInterface;
use App\Services\ApiResponseService;

class AuthApiController extends BaseApiController
{
    protected $userRepository;
    public function __construct(UserRepositoryInterface $userRepository){
        parent::__construct($userRepository);
    }

    public function login(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'password' => 'required',
        ]);

        $user = User::where('name', $request->name)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return ApiResponseService::sendError('Invalid credentials', 401);
        }

        $user->tokens()->delete();
        $token = $user->createToken('auth_token')->plainTextToken;
        $user->role = $user->getRoleNames()->first();
        $result = [
            'token' => $token,
            'user' => $user,
        ];

        return ApiResponseService::sendResponse($result, 'Login successful', 200);
    }

    public function register(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:8',
        ]);

        $user = $this->userRepository->create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        $user->assignRole('admin');

        return ApiResponseService::sendResponse($user, 'Register successful', 200);
    }

    public function logout(Request $request)
    {
        $request->user()->tokens()->delete();

        return ApiResponseService::sendResponse([], 'Logout successful', 200);
    }
}
