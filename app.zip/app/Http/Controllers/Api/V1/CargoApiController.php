<?php

namespace App\Http\Controllers\Api\V1;

use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Http\Resources\CargoResource;
use App\Repositories\MediaRepository;
use App\Http\Resources\CargoCollection;
use App\Http\Requests\StoreCargoRequest;
use App\Repositories\Interfaces\CargoRepositoryInterface;
use App\Repositories\Interfaces\MediaRepositoryInterface;
use App\Repositories\Interfaces\MerchantRepositoryInterface;
use App\Services\ApiResponseService;
use Illuminate\Support\Facades\DB;
use App\Repositories\Interfaces\CarCargoRepositoryInterface;
use App\Services\QrCodeService;
use Carbon\Carbon;

class CargoApiController extends Controller
{
    protected $cargoRepository;
    protected $mediaRepository;
    protected $merchantRepository;
    protected $carCargoRepository;
    public function __construct(CargoRepositoryInterface $cargoRepository, MediaRepositoryInterface $mediaRepository, MerchantRepositoryInterface $merchantRepository, CarCargoRepositoryInterface $carCargoRepository)
    {
        $this->cargoRepository = $cargoRepository;
        $this->mediaRepository = $mediaRepository;
        $this->merchantRepository = $merchantRepository;
        $this->carCargoRepository = $carCargoRepository;
    }

    /**
     * Get all cargos
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-07-21
     */
    public function index()
    {
        $cargos = $this->cargoRepository->getList();
        $cargoCollection = new CargoCollection($cargos);
        if($cargoCollection->isEmpty()) {
            return ApiResponseService::sendResponse(null, 'Cargo list is empty', 200);
        }
        return ApiResponseService::sendResponse($cargoCollection, 'Successfully get cargo list', 200);
    }

    /**
     * Create a new cargo
     * @param StoreCargoRequest $request
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-07-21
     */
    public function store(StoreCargoRequest $request)
    {
        if (!$request->validated()) {
            return ApiResponseService::sendResponse(null, 'Invalid data', 422);
        }
        $cargoData = $request->validated();
        if ($request->hasFile('image')) {
            $media_id = $this->mediaRepository->create($request->file('image'), 'cargos');
            if (!$media_id) {
                return ApiResponseService::sendResponse(null, 'Failed to upload image', 500);
            }
            $cargoData['media_id'] = $media_id;
        }
        if ($request->has('s_name')) {
            if (is_numeric($request->s_name)) {
                $merchant = $this->merchantRepository->findById($request->s_name);
                if ($merchant) {
                    $cargoData['s_merchant_id'] = $merchant->id;
                }
            } else {
                $cargoData['s_name_string'] = $request->s_name;
            }
        }
        if ($request->has('r_name')) {
            if (is_numeric($request->r_name)) {
                $merchant = $this->merchantRepository->findById($request->r_name);
                if ($merchant) {
                    $cargoData['r_merchant_id'] = $merchant->id;
                }
            } else {
                $cargoData['r_name_string'] = $request->r_name;
            }
        }
        unset($cargoData['s_name']);
        unset($cargoData['r_name']);
        $cargoData['cargo_no'] = $this->generateCargoNumber();
        $cargoData['voucher_number'] = $this->generateVoucherNumber();
        $qrcodeData = json_encode($cargoData);
        $qrcodeService = new QrCodeService();
        $path = $qrcodeService->saveQrcode($qrcodeData);
        $cargoData['qrcode_image'] = $path;
        $cargoData['to_pick_date'] = Carbon::parse($cargoData['to_pick_date'])->format('Y-m-d');
        $cargo = $this->cargoRepository->createCargo($cargoData);
        if (!$cargo) {
            return ApiResponseService::sendResponse(null, 'Failed to create cargo', 500);
        }
        $carCargo = $this->carCargoRepository->create([
            'car_id' => null,
            'cargo_id' => $cargo->id,
            'user_id' => null,
            'status' => 'pending',
            'assigned_at' => now(),
            'arrived_at' => null,
        ]);
        return ApiResponseService::sendResponse(new CargoResource($cargo), 'Cargo created successfully', 201);
    }

    /**
     * Get a cargo by id
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-07-21
     */
    public function show($id)
    {
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return ApiResponseService::sendResponse(null, 'Cargo not found', 404);
        }
        return ApiResponseService::sendResponse(new CargoResource($cargo), 'Cargo found successfully', 200);
    }

    /**
     * Update a cargo
     * @param StoreCargoRequest $request
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-07-21
     */
    public function update(StoreCargoRequest $request, $id)
    {
        if (!$request->validated()) {
            return ApiResponseService::sendResponse(null, 'Invalid data', 422);
        }
        $cargoData = $request->validated();
        if ($request->has('s_name')) {
            if (is_numeric($request->s_name)) {
                $merchant = $this->merchantRepository->findById($request->s_name);
                if ($merchant) {
                    $cargoData['s_merchant_id'] = $merchant->id;
                }
            } else {
                $cargoData['s_name_string'] = $request->s_name;
            }
        }
        if ($request->has('r_name')) {
            if (is_numeric($request->r_name)) {
                $merchant = $this->merchantRepository->findById($request->r_name);
                if ($merchant) {
                    $cargoData['r_merchant_id'] = $merchant->id;
                }
            } else {
                $cargoData['r_name_string'] = $request->r_name;
            }
        }
        unset($cargoData['s_name']);
        unset($cargoData['r_name']);
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return ApiResponseService::sendResponse(null, 'Cargo not found', 404);
        }
        if ($request->hasFile('image')) {   
            $media = $this->mediaRepository->update($request->file('image'), 'cargos', $cargo->media_id);
            if (!$media) {
                return ApiResponseService::sendResponse(null, 'Failed to upload image', 500);
            }
            $cargoData['media_id'] = $media->id;
        }
        $cargoData['to_pick_date'] = Carbon::parse($cargoData['to_pick_date'])->format('Y-m-d');
        $updatedCargo = $this->cargoRepository->updateCargo($cargo, $cargoData);
        return ApiResponseService::sendResponse(new CargoResource($updatedCargo), 'Cargo updated successfully', 200);
    }

    /**
     * Delete a cargo
     * @param $id
     * @return \Illuminate\Http\JsonResponse
     * @Author: Hein Htet Aung
     * @Date: 2025-07-21
     */
    public function destroy($id)
    {
        $cargo = $this->cargoRepository->getCargoById($id);
        if (!$cargo) {
            return ApiResponseService::sendResponse(null, 'Cargo not found', 404);
        }
        $this->cargoRepository->deleteCargo($cargo);
        return ApiResponseService::sendResponse(null, 'Cargo deleted successfully', 204);
    }

    private function generateVoucherNumber()
    {
        // Get the latest voucher number and increment
        $latestVoucher = DB::table('cargos')
            ->select('voucher_number')
            ->orderBy('voucher_number', 'desc')
            ->first();

        if ($latestVoucher) {
            $lastNumber = intval($latestVoucher->voucher_number);
            $serial = str_pad($lastNumber + 1, 5, '0', STR_PAD_LEFT);
        } else {
            $serial = '10001';
        }

        return $serial;
    }

    private function generateCargoNumber()
    {
        $date = now()->format('Y');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        return "{$date}-{$random}";
    }
}
