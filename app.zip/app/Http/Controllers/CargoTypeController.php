<?php

namespace App\Http\Controllers;

use App\Models\CargoType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use App\Repositories\Interfaces\CargoTypeRepositoryInterface;

class CargoTypeController extends Controller
{
    protected $cargoTypeRepository;
    public function __construct(CargoTypeRepositoryInterface $cargoTypeRepository)
    {
        $this->cargoTypeRepository = $cargoTypeRepository;
    }

    public function index()
    {
        $cargoTypes = $this->cargoTypeRepository->getList();
        return view('admin.cargo_types.index', compact('cargoTypes'));
    }

    public function getCargoTypes(Request $request)
    {
        $cargoTypes = $this->cargoTypeRepository->getList();
        if ($request->ajax()) {
            return DataTables::of($cargoTypes)
                ->addIndexColumn()
                ->addColumn('action', function ($cargoType) {
                    return '<a href="' . route('admin.cargo_types.edit', $cargoType->id) . '" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i></a>
                    <form id="delete-form' . $cargoType->id . '" action="' . route('admin.cargo_types.destroy', $cargoType->id) . '" method="POST" style="display: none;">
                        ' . csrf_field() . '
                        ' . method_field('DELETE') . '
                        </form>
                        <button type="submit" onclick="return confirmDelete(' . $cargoType->id . ')" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
                    ';
                })
                ->addColumn('status', function ($cargoType) {
                    return ($cargoType->status === 'active') ? '<span class="badge bg-success">အသုံးပြုနေသည်</span>' : '<span class="badge bg-danger">အသုံးပြုမှုမရှိသည်</span>';
                })
                ->rawColumns(['action', 'status'])
                ->make(true);
        }
        return view('admin.cargo_types.index', compact('cargoTypes'));
    }

    public function create()
    {
        return view('admin.cargo_types.create');
    }

    public function store(Request $request)
    {
        $validate = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'required|string|max:255',
        ]);
        try {
            DB::beginTransaction();
            $this->cargoTypeRepository->createCargoType($validate);
            DB::commit();
            return redirect()->route('admin.cargo_types.index')->with('success', 'Cargo type created successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('admin.cargo_types.index')->with('error', 'Cargo type creation failed');
        }
    }

    public function edit($id)
    {
        $cargoType = $this->cargoTypeRepository->getCargoTypeById($id);
        return view('admin.cargo_types.edit', compact('cargoType'));
    }

    public function update(Request $request, $id)
    {
        $validate = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'status' => 'required|string|max:255',
        ]);
        try {
            DB::beginTransaction();
            $this->cargoTypeRepository->updateCargoType($id, $validate);
            DB::commit();
            return redirect()->route('admin.cargo_types.index')->with('success', 'Cargo type updated successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('admin.cargo_types.index')->with('error', 'Cargo type update failed');
        }
    }

    public function destroy($id)
    {
        $this->cargoTypeRepository->deleteCargoType($id);
        return redirect()->route('admin.cargo_types.index')->with('success', 'Cargo type deleted successfully');
    }
}
