<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreTransitCargoRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }
    
    /**
     * Prepare the data for validation.
     */
    protected function prepareForValidation()
    {
        $this->merge([
            's_nrc' => $this->s_nrc ?? 'N/A',
            'r_nrc' => $this->r_nrc ?? 'N/A',
        ]);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public static function rules(): array
    {
        return [
            's_name'         => 'required|string|max:50',
            's_phone'        => 'required|string|max:20',
            's_nrc'          => 'required|string|max:20',
            's_address'      => 'required|string|max:50',

            'r_name'         => 'required|string|max:50',
            'r_phone'        => 'required|string|max:20',
            'r_nrc'          => 'required|string|max:20',
            'r_address'      => 'required|string|max:50',

            'cargo_no'       => 'nullable|string|max:50',
            'from_city'      => 'required|string|max:50',
            'to_city'        => 'required|string|max:50',
            'from_gate'      => 'required|string|max:50',
            'to_gate'        => 'required|string|max:50',
            'quantity'       => 'required|integer|min:1',
            'cargo_type_id'     => 'required|integer|exists:cargo_types,id',
            'image'          => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',    
            'status'         => 'required|in:registered, delivered, taken, lost, deleted',

            'service_charge' => 'required|numeric|min:0',
            'is_debt'        => 'required|boolean',

            'to_pick_date'   => 'required|date',
            'voucher_number' => 'nullable|string|max:50',
            'car_id'         => 'required|integer|exists:cars,id',
        ];
    }
}
