// <?php

// namespace App\Models;

// use Illuminate\Database\Eloquent\Factories\HasFactory;
// use Illuminate\Database\Eloquent\Model;

// class CargoItem extends Model
// {
//     use HasFactory;

//     protected $fillable = [
//         'cargo_id',
//         'cargo_type_id',
//         'quantity',
//         'cargo_detail_name',
//         'notice_message',
//     ];

//     public function cargo()
//     {
//         return $this->belongsTo(Cargo::class, 'cargo_id');
//     }

//     public function cargoType()
//     {
//         return $this->belongsTo(CargoType::class, 'cargo_type_id');
//     }
// }