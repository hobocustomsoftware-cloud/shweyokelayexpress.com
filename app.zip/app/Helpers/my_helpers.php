<?php
use Illuminate\Support\Facades\DB;

if (!function_exists('changeCargoStatusMM')) {
    function changeCargoStatusMM($status)
    {
        // 
    }
}

if (!function_exists('generateCargoNumber')) {
    function generateCargoNumber()
    {
        $date = now()->format('Y');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        return "{$date}-{$random}";
    }
}

if (!function_exists('generateVoucherNumber')) {
    function generateVoucherNumber()
    {
        $latestVoucher = DB::table('cargos')
            ->select('voucher_number')
            ->orderBy('voucher_number', 'desc')
            ->first();

        if ($latestVoucher) {
            $lastNumber = intval($latestVoucher->voucher_number);
            $serial = str_pad($lastNumber + 1, 5, '0', STR_PAD_LEFT);
        } else {
            $serial = '10001';
        }

        return $serial;
    }
}
if (!function_exists('generateTransitCargoNumber')) {
    function generateTransitCargoNumber()
    {
        $date = now()->format('Y');
        $random = str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
        return "{$date}-{$random}";
    }
}

if (!function_exists('generateTransitCargoVoucherNumber')) {
    function generateTransitCargoVoucherNumber()
    {
        $latestVoucher = DB::table('transit_cargos')
            ->select('voucher_number')
            ->orderBy('voucher_number', 'desc')
            ->first();

        if ($latestVoucher) {
            $lastNumber = intval($latestVoucher->voucher_number);
            $serial = str_pad($lastNumber + 1, 5, '0', STR_PAD_LEFT);
        } else {
            $serial = '10001';
        }

        return $serial;
    }

    if (!function_exists('generateTransitPassengerVoucherNumber')) {
        function generateTransitPassengerVoucherNumber()
        {
            $latestVoucher = DB::table('transit_passengers')
                ->select('voucher_number')
                ->orderBy('voucher_number', 'desc')
                ->first();

            if ($latestVoucher) {
                $lastNumber = intval($latestVoucher->voucher_number);
                $serial = str_pad($lastNumber + 1, 5, '0', STR_PAD_LEFT);
            } else {
                $serial = '10001';
            }

            return $serial;
        }
    }
}
