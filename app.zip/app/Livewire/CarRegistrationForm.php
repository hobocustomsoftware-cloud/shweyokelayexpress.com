<?php

namespace App\Livewire;

use App\Repositories\CityRepository;
use App\Repositories\CarRepository;
use App\Repositories\DayOffDateRepository;
use Livewire\Component;
use App\Http\Requests\StoreCarRequest;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Log;

class CarRegistrationForm extends Component
{

    public $cities;
    public $number;
    public $departure_date;
    public $from;
    public $to;
    public $driver_name;
    public $driver_phone_number;
    public $assistant_driver_name;
    public $assistant_driver_phone;
    public $spare_name;
    public $spare_phone;
    public $crew_name;
    public $crew_phone;

    protected $cityRepository;
    protected $carRepository;
    protected $dayOffDateRepository;

    public $id;
    public $form_type;
    public $departure_time;
    public $day_off_date;
    public $reason;

    public function boot(CityRepository $cityRepository, CarRepository $carRepository, DayOffDateRepository $dayOffDateRepository)
    {
        $this->cityRepository = $cityRepository;
        $this->carRepository = $carRepository;
        $this->dayOffDateRepository = $dayOffDateRepository;
    }

    public function mount($form_type, $id)
    {
        $this->cities = $this->cityRepository->getAllCities();
        if ($id) {
            $this->id = $id;
            $car = $this->carRepository->getById($id);
            if (!$car) {
                return redirect()->back()->with('error', 'ကားအချက်အလက်များမရှိပါ');
            }
        }
        $this->form_type = $form_type;
        if ($form_type == 'edit') {
            $this->fill($car->toArray());
            $car_id = $car->id;
            Log::info('CarRegistrationForm: car_id', [$car_id]);
            // Load a single record for this car; model casts day_off_date to array
            $dayOff = $this->dayOffDateRepository->getByCarId($car_id)->first();
            if ($dayOff) {
                $dates = is_array($dayOff->day_off_date) ? $dayOff->day_off_date : [];
                $this->day_off_date = implode(', ', $dates);
            } else {
                $this->day_off_date = '';
            }
        }
    }

    public function updatedFrom($from)
    {
        $this->dispatch('reinitDatePickers');
    }

    public function updatedTo($to)
    {
        $this->dispatch('reinitDatePickers');
    }

    public function save()
    {
        try {

            $rules = (new StoreCarRequest())->rules();

            $ruleKeys = array_keys($rules);
            $propsSnapshot = [];
            foreach ($ruleKeys as $key) {
                $prop = explode('.', $key)[0];
                if (property_exists($this, $prop)) {
                    $propsSnapshot[$prop] = $this->$prop;
                }
            }
            Log::debug('CarRegistrationForm: component props snapshot', $propsSnapshot);

            $validated = $this->validate($rules);
            // Create car first (day_off_date is not a cars table column)
            $carData = $validated;
            unset($carData['day_off_date']);
            $car = $this->carRepository->create($carData);
            if (!$car) {
                return redirect()->back()->with('error', 'ကားအချက်အလက်များသွင်းမည့်အောင်မြင်မှုမရှိပါ');
            }
            // Persist day-off dates as a single JSON array row for this car
            $car_id = $car->id;
            $datesInput = $validated['day_off_date'] ?? '';
            $dates = array_values(array_filter(array_map(function($d){ return trim($d); }, explode(',', (string)$datesInput))));
            $created = $this->dayOffDateRepository->create([
                'car_id' => $car_id,
                'day_off_date' => $dates,
                'reason' => $this->reason ?? ''
            ]);
            if (!$created) {
                return redirect()->back()->with('error', 'ကားမထွက်မည့်နေ့စွဲထည့်သွင်းမည့်အောင်မြင်မှုမရှိပါ');
            }
            return redirect()->route('admin.cars.index')->with('success', 'ကားအချက်အလက်များသွင်းမည့်အောင်မြင်ပါသည်');
        } catch (ValidationException $e) {
            Log::error('Validation failed', [
                'errors' => $e->errors()
            ]);
            throw $e;
        }
    }

    public function update()
    {
        try {
            $rules = (new StoreCarRequest())->rules();

            $ruleKeys = array_keys($rules);
            $propsSnapshot = [];
            foreach ($ruleKeys as $key) {
                $prop = explode('.', $key)[0];
                if (property_exists($this, $prop)) {
                    $propsSnapshot[$prop] = $this->$prop;
                }
            }
            Log::debug('CarRegistrationForm: component props snapshot', $propsSnapshot);

            $validated = $this->validate($rules);
            // Update car (exclude day_off_date)
            $carData = $validated;
            unset($carData['day_off_date']);
            $car = $this->carRepository->update($this->id, $carData);
            if (!$car) {
                return redirect()->back()->with('error', 'ကားအချက်အလက်များပြုပြင်မည့်အောင်မြင်မှုမရှိပါ');
            }
            // Upsert a single row for this car with the array of dates
            $datesInput = $validated['day_off_date'] ?? '';
            $dates = array_values(array_filter(array_map(function($d){ return trim($d); }, explode(',', (string)$datesInput))));
            $existing = $this->dayOffDateRepository->getByCarId($this->id)->first();
            if ($existing) {
                $updated = $this->dayOffDateRepository->update($existing->id, [
                    'day_off_date' => $dates,
                    'reason' => $this->reason ?? ''
                ]);
                if (!$updated) {
                    return redirect()->back()->with('error', 'ကားမထွက်မည့်နေ့စွဲပြုပြင်မည့်အောင်မြင်မှုမရှိပါ');
                }
            } else {
                $created = $this->dayOffDateRepository->create([
                    'car_id' => $this->id,
                    'day_off_date' => $dates,
                    'reason' => $this->reason ?? ''
                ]);
                if (!$created) {
                    return redirect()->back()->with('error', 'ကားမထွက်မည့်နေ့စွဲပြုပြင်မည့်အောင်မြင်မှုမရှိပါ');
                }
            }
            return redirect()->route('admin.cars.index')->with('success', 'ကားအချက်အလက်များပြုပြင်မည့်အောင်မြင်ပါသည်');
        } catch (ValidationException $e) {
            Log::error('Validation failed', [
                'errors' => $e->errors()
            ]);
            throw $e;
        }
    }

    public function render()
    {
        return view('livewire.car-registration-form');
    }
}
